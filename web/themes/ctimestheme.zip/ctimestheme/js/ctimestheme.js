/**
 * @file
 * ctimestheme behaviors.
 */
(function (Drupal) {

  'use strict';

  Drupal.behaviors.ctimestheme = {
    attach (context, settings) {

      console.log('It works!');

    }
  };

} (Drupal));
